#include "Kernel.h"

int main() {
    Kernel kernel(3);
    kernel.iniciar();
    return 0;
}
